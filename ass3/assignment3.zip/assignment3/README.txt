CO-OCCURRENCE:
the relevant file for this is co_occurrence_similarity.py
if you would like to run it on different file then we had to run it on you can go to line 90 and change the file name to one you choose
running command is: python3 co_occurrence_similarity.py

WORD2VEC:
the relevant files are vec_similarity.py, and vecs_asarray.py
vecs_asarray.py is the file we put the vectors for the words (instead of iterating the file twice we did it once and saved the vectors)
vec_similarity.py is the file that iterating the file, finding the closest vectos and printing them.
if you would like to change the file names you can change them in lines 22-25
you can run the code using the command: python3 vec_similarity.py